# SMTP Relay

Production-ready SMTP relay for Windows.